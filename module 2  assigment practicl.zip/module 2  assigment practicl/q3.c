#include<stdio.h>
main()
{
		int     number; // use for whith out decimal number 1,2,-2
		float   decimal_value;//used for decimal value 3.14
		char     adii; // use for single chrcter 'a'
		const float pi=3.14;// value is not chang 
	    
	    
	    printf("%f",pi);
	    
	    printf("\nenter a number");
	    scanf("%d",&number);
	    
	    printf("\nenter a decimal value");
	    scanf("%f",&decimal_value);
	    
	    printf("\n enter adii");
	    scanf("%c",&adii);
	    
	    
		
}
