#include<stdio.h>
  main()
  {
  	
  	int n;
  	printf("enter number");
  	scanf("%d",&n);
  	
  	if (n%2==0)
  	{
  		printf("\n this is even number");
	  }
	  
	else 
	{
		printf("\n this is odd number");
	}
  	
  	
  	
  	
  	
  	
  	
  	
  	
  }
