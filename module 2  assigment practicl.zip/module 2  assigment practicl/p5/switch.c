#include<stdio.h>
main()
{
	int month;
	
	printf("enter a month");
	scanf("%d",&month);
	switch(month)
	{
		case 1:
			{
				printf("January,");
			}
			break;
			
		case 2:
			{
				printf(" February");
			}
			break;
		
		case 3:
			{
				printf("March");
			}
			break;
			
		case 4:
			{
				printf("april");
			}
		break;
		
				
		case 5:
			{
				printf("may");
			}
		break;
		
				
		case 6:
			{
				printf("june");
			}
		break;
		
				
		case 7:
			{
				printf("july");
			}
		break;
		
				
		case 8:
			{
				printf("augest");
			}
		break;
		
				
		case 9:
			{
				printf("september");
			}
		break;
		
				
		case 10:
			{
				printf("octomber");
			}
		break;
		
				
		case 11:
			{
				printf("november");
			}
		break;
		
				
		case 12:
			{
				printf("decmber");
			}
		break;
		
		default:
		{
		printf("wrog choice");
		}
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
	
}
