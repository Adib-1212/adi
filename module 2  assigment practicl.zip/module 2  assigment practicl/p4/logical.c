#include<stdio.h>
main()
{
	
	 int a,b;
	 printf("enter a");
	 scanf("%d",&a);
	 
	 printf("enter b");
	 scanf("%d",&b);
	 
	 printf("%d && %d=%d",a,b,a&&b);
	 printf("%d || %d=%d",a,b,a||b);
	
	 
	 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
