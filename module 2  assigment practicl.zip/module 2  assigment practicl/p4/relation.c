/* 
relaattion operrator
==,>,<,<=,>=,!=

*/

#include<stdio.h>
main()
{	
  int a,b;
  printf("\n enter a");
  scanf("%d",&a);
  
  printf("\n enter b");
  scanf("%d",&b);
  
   printf("\n %d==%d=%d",a,b,a==b);
   printf("\n %d>%d=%d",a,b,a>b);
   printf("\n %d<%d=%d",a,b,a<b);
   printf("\n %d>=%d=%d",a,b,a>=b);
   printf("\n %d<=%d=%d",a,b,a<=b);
   printf("\n %d!=%d=%d",a,b,!a==b);
  
  
}
