#include<stdio.h>
main()
{
	int i=1;
	do 
	{
		printf("\n %d",i);
		i++;
	}
	while(i<=10);
	
	
	
}
