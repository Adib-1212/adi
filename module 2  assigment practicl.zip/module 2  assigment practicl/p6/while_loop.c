#include<stdio.h>
 main()
 {
 		int i;
 		while(i<=10)
 		{
 			printf("\n \t i =%d",i);
 			i++;
		 }
 		
 		
 		
 		
 		
 }
