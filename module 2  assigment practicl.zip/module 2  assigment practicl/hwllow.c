#include<stdio.h>
main()
{
	printf("hellow world");
}
